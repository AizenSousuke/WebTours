Action()
{

	web_websocket_connect("ID=0", 
		"URI=ws://127.0.0.1:1001/?cid=170455562", 
		"Origin=chrome-extension://ngpampappnmepgilojfohadhhmbhlaek", 
		"OnOpenCB=OnOpenCB0", 
		"OnMessageCB=OnMessageCB0", 
		"OnErrorCB=OnErrorCB0", 
		"OnCloseCB=OnCloseCB0", 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer/Bin="
		"\\x4D\\x53\\x47\\x23\\x31\\x23\\x32\\x23\\x31\\x23\\x30\\x3A\\x37\\x3A\\x31\\x37\\x3A\\x37\\x3A\\x30\\x2C\\x31\\x31\\x32\\x3D\\x31\\x39\\x3A\\x43\\x68\\x72\\x6F\\x6D\\x65\\x2F\\x37\\x37\\x2E\\x30\\x2E\\x33\\x38\\x36\\x35\\x2E\\x37\\x35\\x2C\\x31\\x31\\x33\\x3D\\x31\\x39\\x3A\\x43\\x68\\x72\\x6F\\x6D\\x65\\x2F\\x37\\x37\\x2E\\x30\\x2E\\x33\\x38\\x36\\x35\\x2E\\x37\\x35\\x2C\\x31\\x31\\x34\\x3D\\x32\\x37\\x3A\\x43\\x68\\x72\\x6F\\x6D\\x65\\x5F\\x52\\x65\\x6E\\x64\\x65\\x72\\x57\\x69\\x64\\x67\\x65\\"
		"x74\\x48\\x6F\\x73\\x74\\x48\\x57\\x4E\\x44\\x2C\\x31\\x31\\x36\\x3D\\x35\\x3A\\x65\\x6E\\x2D\\x55\\x53\\x3B", 
		"IsBinary=1", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("webtours", 
		"URL=http://127.0.0.1:1080/webtours", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Sec-Fetch-User");

	web_add_auto_header("Sec-Fetch-Mode", 
		"nested-navigate");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("Origin", 
		"http://127.0.0.1:1080");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_submit_form("login.pl", 
		"Snapshot=t23.inf", 
		ITEMDATA, 
		"Name=username", "Value=jojo", ENDITEM, 
		"Name=password", "Value=bean", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_image("Search Flights Button", 
		"Alt=Search Flights Button", 
		"Snapshot=t24.inf", 
		LAST);

	web_add_auto_header("Origin", 
		"http://127.0.0.1:1080");

	web_submit_form("reservations.pl", 
		"Snapshot=t25.inf", 
		ITEMDATA, 
		"Name=depart", "Value=Denver", ENDITEM, 
		"Name=departDate", "Value=09/19/2019", ENDITEM, 
		"Name=arrive", "Value=Los Angeles", ENDITEM, 
		"Name=returnDate", "Value=09/20/2019", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=roundtrip", "Value=<OFF>", ENDITEM, 
		"Name=seatPref", "Value=Aisle", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		LAST);

	web_submit_form("reservations.pl_2", 
		"Snapshot=t26.inf", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=030;251;09/19/2019", ENDITEM, 
		"Name=reserveFlights.x", "Value=29", ENDITEM, 
		"Name=reserveFlights.y", "Value=10", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("Origin", 
		"http://127.0.0.1:1080");

	lr_think_time(12);

	web_submit_form("reservations.pl_3", 
		"Snapshot=t27.inf", 
		ITEMDATA, 
		"Name=firstName", "Value=Jojo", ENDITEM, 
		"Name=lastName", "Value=Bean", ENDITEM, 
		"Name=address1", "Value=", ENDITEM, 
		"Name=address2", "Value=", ENDITEM, 
		"Name=pass1", "Value=Jojo Bean", ENDITEM, 
		"Name=creditCard", "Value=12345678", ENDITEM, 
		"Name=expDate", "Value=06/19", ENDITEM, 
		"Name=saveCC", "Value=<OFF>", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_image("Itinerary Button", 
		"Alt=Itinerary Button", 
		"Snapshot=t28.inf", 
		LAST);

	web_revert_auto_header("Sec-Fetch-User");

	web_image("SignOff Button", 
		"Alt=SignOff Button", 
		"Snapshot=t29.inf", 
		LAST);

	return 0;
}